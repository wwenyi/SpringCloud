package com.wwy.exception;

public class NoTokenException extends Exception{
	private static final long serialVersionUID = 189814627576920175L;
	public NoTokenException() {
		super();
	}
	public NoTokenException(String smg) {
		super(smg);
	}
	
	
}

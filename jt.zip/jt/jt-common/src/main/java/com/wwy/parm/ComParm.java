package com.wwy.parm;
/**
 * 公共参数
 * @author wwy
 * @date 2019年12月6日
 * @version v0.0.1
 *
 */
public class ComParm {
public static final String KEY="wwy";
public static final String QF="wwy";

public static final int TIME=60*60*24;

}

package com.wwy.test.mybatisplustest.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wwy.entry.Order;

public interface MBPDao extends BaseMapper<Order>{

}
